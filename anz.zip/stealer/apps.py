from django.apps import AppConfig


class StealerConfig(AppConfig):
    name = 'stealer'
